🚌 Bus Reservation Website - Simple Project

📌 How to Run:
1. Make sure Python is installed.
2. Install Streamlit:
   pip install streamlit
3. Run the project:
   streamlit run app.py
4. Open in browser:
   http://localhost:8501

📁 Files included:
- app.py (Main code)
- reservations.json (Data storage)
- README.txt (Instructions)

✅ Developed for Project Submission