import streamlit as st
import json
import os

DATA_FILE = "reservations.json"

# ---------------- DATA ---------------- #
class Bus:
    def __init__(self, bus_id, route, rows, seats_per_row, price_per_seat):
        self.bus_id = bus_id
        self.route = route
        self.rows = rows
        self.seats_per_row = seats_per_row
        self.price_per_seat = price_per_seat
        self.seats = [["O" for _ in range(seats_per_row)] for _ in range(rows)]
        self.available_seats = rows * seats_per_row

# ---------------- App ---------------- #
st.set_page_config(page_title="🚌 Bus Reservation System", page_icon="🚌", layout="wide")

# Initialize buses
if "buses" not in st.session_state:
    st.session_state.buses = [
        Bus("B1", "Kolhapur → Mumbai", 5, 4, 300),
        Bus("B2", "Nagpur → Sangli", 5, 4, 350),
        Bus("B3", "Pune → Bangalore", 5, 4, 400),
        Bus("B4", "Delhi → Chandigarh", 5, 4, 250),
    ]

# Load reservations
def load_reservations():
    if os.path.exists(DATA_FILE):
        try:
            with open(DATA_FILE) as f:
                return json.load(f)
        except:
            return {}
    return {}

def save_reservations(reservations):
    with open(DATA_FILE, "w") as f:
        json.dump(reservations, f, indent=4)

if "reservations" not in st.session_state:
    st.session_state.reservations = load_reservations()
    # Update seat status
    for det in st.session_state.reservations.values():
        bus = next((b for b in st.session_state.buses if b.bus_id == det["bus_id"]), None)
        if bus:
            bus.seats[det["row"]][det["seat"]] = "X"
            bus.available_seats -= 1

# ---------------- Main Interface ---------------- #
st.title("🚌 Modern Bus Reservation System")
menu = ["View Buses", "Make Reservation", "Cancel Reservation", "Show Reservations"]
choice = st.sidebar.selectbox("Menu", menu)

# ---------------- View Buses ---------------- #
if choice == "View Buses":
    st.subheader("Available Buses")
    for bus in st.session_state.buses:
        st.write(f"**{bus.bus_id} - {bus.route}** | Seats Left: {bus.available_seats} | Price: ₹{bus.price_per_seat}")

# ---------------- Make Reservation ---------------- #
elif choice == "Make Reservation":
    st.subheader("Reserve Your Seat")
    bus_options = [f"{b.bus_id} - {b.route}" for b in st.session_state.buses]
    selected_bus = st.selectbox("Select Bus", bus_options)
    bus = st.session_state.buses[bus_options.index(selected_bus)]

    st.write(f"Price per seat: ₹{bus.price_per_seat}")
    st.write("**Seat Layout (O=Available, X=Booked)**")

    for r in range(bus.rows):
        row_display = ""
        for c in range(bus.seats_per_row):
            row_display += bus.seats[r][c] + " "
        st.text(f"Row {r+1}: {row_display}")

    row = st.number_input("Select Row (1-indexed)", min_value=1, max_value=bus.rows)
    seat = st.number_input("Select Seat (1-indexed)", min_value=1, max_value=bus.seats_per_row)
    name = st.text_input("Enter Your Name")

    if st.button("Reserve"):
        r_idx = int(row)-1
        s_idx = int(seat)-1
        if bus.seats[r_idx][s_idx] == "X":
            st.error("Seat already reserved!")
        elif not name:
            st.error("Enter a valid name!")
        else:
            res_id = f"{bus.bus_id}{r_idx}{s_idx}"
            st.session_state.reservations[res_id] = {
                "name": name,
                "bus_id": bus.bus_id,
                "route": bus.route,
                "row": r_idx,
                "seat": s_idx
            }
            bus.seats[r_idx][s_idx] = "X"
            bus.available_seats -= 1
            save_reservations(st.session_state.reservations)
            st.success(f"Seat {row}-{seat} reserved for {name} ✅")

# ---------------- Cancel Reservation ---------------- #
elif choice == "Cancel Reservation":
    st.subheader("Cancel a Reservation")
    rid = st.text_input("Enter Reservation ID to Cancel")
    if st.button("Cancel"):
        if rid in st.session_state.reservations:
            det = st.session_state.reservations[rid]
            bus = next((b for b in st.session_state.buses if b.bus_id == det["bus_id"]), None)
            if bus:
                bus.seats[det["row"]][det["seat"]] = "O"
                bus.available_seats += 1
            del st.session_state.reservations[rid]
            save_reservations(st.session_state.reservations)
            st.success(f"Reservation {rid} cancelled successfully ✅")
        else:
            st.error("Invalid Reservation ID!")

# ---------------- Show Reservations ---------------- #
elif choice == "Show Reservations":
    st.subheader("All Reservations")
    if not st.session_state.reservations:
        st.info("No reservations found!")
    else:
        for rid, det in st.session_state.reservations.items():
            st.write(f"ID: {rid} | Name: {det['name']} | Bus: {det['bus_id']} | Route: {det['route']} | Seat: Row {det['row']+1}, Seat {det['seat']+1}")
